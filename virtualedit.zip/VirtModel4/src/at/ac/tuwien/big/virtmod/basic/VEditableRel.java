package at.ac.tuwien.big.virtmod.basic;

public interface VEditableRel {

}
