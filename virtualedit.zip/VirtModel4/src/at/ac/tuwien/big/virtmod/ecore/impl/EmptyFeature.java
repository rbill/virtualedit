package at.ac.tuwien.big.virtmod.ecore.impl;

import at.ac.tuwien.big.virtmod.ecore.Feature;

public class EmptyFeature implements Feature {

}
