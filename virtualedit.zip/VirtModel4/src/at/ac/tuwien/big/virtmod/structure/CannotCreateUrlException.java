package at.ac.tuwien.big.virtmod.structure;

public class CannotCreateUrlException extends Exception {

}
