package at.ac.tuwien.big.virtmod.ecore.impl;

import at.ac.tuwien.big.virtmod.ecore.FeaturePropertyValue;

public class EmptyFeaturePropertyValue implements FeaturePropertyValue {

}
