package at.ac.tuwien.big.virtmod.ecore.impl;

public class ConcreteSingleFeatureValue {

}
