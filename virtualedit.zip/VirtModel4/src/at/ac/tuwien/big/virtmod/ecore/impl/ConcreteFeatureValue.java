package at.ac.tuwien.big.virtmod.ecore.impl;

import at.ac.tuwien.big.virtmod.ecore.VListFeaturePropertyValue;

public class ConcreteFeatureValue<T> implements VListFeaturePropertyValue<T> {

}
