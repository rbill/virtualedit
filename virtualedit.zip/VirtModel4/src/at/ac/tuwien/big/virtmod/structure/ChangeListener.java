package at.ac.tuwien.big.virtmod.structure;

public interface ChangeListener<T> {
	
	public void onchange(T obj);

}
