package at.ac.tuwien.big.virtmod.basic;

public interface PosEditState {
	
	public int getIndex(TreeposType type);
	
	public int popIndex(TreeposType type);
	
}
