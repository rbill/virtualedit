package at.ac.tuwien.big.virtmod.basic;

public enum TreeposType {
	NORMAL();
		
	private TreeposType() {
	}
		

}
