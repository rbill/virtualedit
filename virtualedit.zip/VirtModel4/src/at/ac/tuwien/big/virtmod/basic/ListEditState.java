package at.ac.tuwien.big.virtmod.basic;

public interface ListEditState extends Editstate {
	
	public PosEditState getEditState(Treepos pos);

}
