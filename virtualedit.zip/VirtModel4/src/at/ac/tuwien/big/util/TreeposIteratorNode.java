package at.ac.tuwien.big.util;

import at.ac.tuwien.big.virtmod.basic.Treepos;

public interface TreeposIteratorNode<U> extends IteratorNode<Treepos,U> {

	U  getValue();

}
